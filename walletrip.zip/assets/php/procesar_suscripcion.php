<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["email"])) {
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Configuración del correo de confirmación
        $destinatario_confirmacion = $email;
        $asunto_confirmacion = "Confirmación de suscripción a Walletrip";
        $mensaje_confirmacion = "¡Gracias por suscribirte a Walletrip!\n\nTu dirección de correo electrónico $email ha sido registrada con éxito.\n\n¡Bienvenido a nuestra comunidad!";
        $cabeceras_confirmacion = "From: marketing@walletrip.com";

        if (mail($destinatario_confirmacion, $asunto_confirmacion, $mensaje_confirmacion, $cabeceras_confirmacion)) {
            $destinatario_notificacion = "marketing@walletrip.com";
            $asunto_notificacion = "Nuevo suscriptor";
            $mensaje_notificacion = "Se ha suscrito un nuevo usuario con el correo: $email";

            if (mail($destinatario_notificacion, $asunto_notificacion, $mensaje_notificacion)) {
                
                // Conexión a la base de datos
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "u973804478_contacto";

                $conn = new mysqli($servername, $username, $password, $dbname);

                if ($conn->connect_error) {
                    die("Conexión fallida: " . $conn->connect_error);
                }

                // Inserción segura utilizando sentencias preparadas
                $sql = $conn->prepare("INSERT INTO subscribers(email, timestamp) VALUES (?, NOW())");
                $sql->bind_param("s", $email);

                if ($sql->execute()) {
                    echo "Te has suscrito correctamente. Se ha enviado un correo de confirmación a tu dirección.";
                } else {
                    echo "Error al suscribirse: " . $sql->error;
                }

                $sql->close();
                $conn->close();
            } else {
                echo "Hubo un error al enviar el correo de notificación.";
            }
        } else {
            echo "Hubo un error al enviar el correo de confirmación.";
        }
    } else {
        echo "El correo electrónico proporcionado no es válido.";
    }
} else {
    echo "Por favor, proporciona un correo electrónico.";
}
?>

