<?php

// Datos para la conexión a la base de datos
$servername = "localhost";
$username = "u973804478_viajes";
$password = "Reinventa_02558614";
$dbname = "u973804478_viajes";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Chequear conexión
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Recoger datos del formulario
$packageName = $_POST['PackageName'];
$name = $_POST['Name'];
$email = $_POST['Email'];
$phone = $_POST['Phone'];
$date = $_POST['Date'];
$nights = $_POST['Nights'];
$adults = $_POST['Adults'];
$childrens = $_POST['Childrens'];
$observations = $_POST['Observations'];
$acceptsPolicies = isset($_POST['aceptaPoliticas']) ? 1 : 0;

// Preparar la sentencia SQL
$stmt = $conn->prepare("INSERT INTO cotizaciones (PackageName, Name, Email, Phone, Date, Nights, Adults, Childrens, Observations, AcceptsPolicies) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

$stmt->bind_param("sssssiisis", $packageName, $name, $email, $phone, $date, $nights, $adults, $childrens, $observations, $acceptsPolicies);

// Ejecutar la sentencia
if ($stmt->execute()) {
    // Enviar correo al usuario
    $toUser = $email;
    $subjectUser = "Confirmación de Cotización - " . $packageName;
    $messageUser = "Hola " . $name . ",\n\nGracias por solicitar información sobre " . $packageName . ". Nos pondremos en contacto contigo pronto.\n\nDetalles de tu solicitud:\nNombre del Plan: " . $packageName . "\nFecha Tentativa de Viaje: " . $date . "\nNúmero de Noches: " . $nights . "\nAdultos: " . $adults . "\nNiños: " . $childrens . "\nObservaciones: " . $observations . "\n\nEste correo es una confirmación automática de la recepción de tu solicitud.";
    $headersUser = "From: no-reply@walletrip.com";
    mail($toUser, $subjectUser, $messageUser, $headersUser);
    
    // Enviar correo al equipo de desarrollo
    $toDev = "reservas@walletrip.com";
    $subjectDev = "Nueva Solicitud de Cotización - " . $packageName;
    $messageDev = "Se ha recibido una nueva solicitud de cotización.\n\nDetalles:\nNombre: " . $name . "\nEmail: " . $email . "\nTeléfono: " . $phone . "\nFecha Tentativa de Viaje: " . $date . "\nNúmero de Noches: " . $nights . "\nAdultos: " . $adults . "\nNiños: " . $childrens . "\nObservaciones: " . $observations;
    $headersDev = "From: no-reply@walletrip.com";
    mail($toDev, $subjectDev, $messageDev, $headersDev);
    
    // Redirigir a la página de confirmación
    header("Location: ../../confirmacion-contacto.html");
    exit;
} else {
    echo "Error: " . $stmt->error;
}

// Cerrar sentencia y conexión
$stmt->close();
$conn->close();
?>
