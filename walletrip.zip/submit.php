<?php
  if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $recaptcha_secret = "6LflGswpAAAAAFiJaj29njh_iQmNnJYniWygtLsi";
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=" . $recaptcha_secret . "&response=" . $_POST['g-recaptcha-response']);
    $response = json_decode($response);

    if ($response->success === true) {
      echo "Verificación exitosa. Formulario enviado.";
    } else {
      echo "Verificación de reCAPTCHA fallida. Intenta nuevamente.";
    }
  }
?>
